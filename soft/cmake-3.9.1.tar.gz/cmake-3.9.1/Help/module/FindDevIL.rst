.. cmake-module:: ../../Modules/FindDevIL.cmake
