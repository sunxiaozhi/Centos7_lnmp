.. cmake-module:: ../../Modules/FindTclsh.cmake
