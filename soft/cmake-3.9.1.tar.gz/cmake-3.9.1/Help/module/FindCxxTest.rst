.. cmake-module:: ../../Modules/FindCxxTest.cmake
